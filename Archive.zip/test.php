<?php require 'includes/db_conn.php'; ?>

<html>
	<head>
		<title>Test File</title>
	</head>
	<body>
		<?php
			$result = $db->query("SELECT * FROM `sales_voucher`");
			
			$sales_array = array();
			while($row = $result->fetch_assoc()){
				//$sales_array = array($row['sales_id'] => $row['sales_voucher']);
				$sales_array['sales_id'] = $row['sales_id'];
				$sales_array['amount'] = $row['sales_voucher'];
			}
			echo "<pre>";
			echo print_r($sales_array);
			echo "</pre>";
		
		?>
	</body>
</html>